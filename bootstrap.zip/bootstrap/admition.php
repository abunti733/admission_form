<?php

$hostname = "localhost";
$usernamex = "root";
$password = "";
$database_name = "student_form";
$db_con=mysqli_connect($hostname , $usernamex , $password , $database_name);


if(isset($_POST['register'])){
  $name=$_POST['name'];
  $father_name=$_POST['father_name'];
  $mother_name=$_POST['mother_name'];
  $dob=$_POST['dob'];
  $religion=$_POST['religion'];
  $gender=$_POST['gender'];
  $job_title=$_POST['job_title'];
  $blood_group=$_POST['blood_group'];
  $nid_birth_certificate=$_POST['nid_birth_certificate'];
  $course_type=$_POST['course_type'];
  $phone_number=$_POST['phone_number'];
  $guardian_number=$_POST['guardian_number'];
  $email=$_POST['email'];
  $divisions=$_POST['divisions'];
  $distr=$_POST['distr'];
  $thana=$_POST['thana'];
  $post_office=$_POST['post_office'];
  $village=$_POST['village'];
  $session=$_POST['session'];
  $course=$_POST['course'];
  $reg_type=$_POST['reg_type'];
  $total_fee=$_POST['total_fee'];
      $input_error=array();
      if(empty($name)){
          $input_error['name']="name is required";
      }
      if(empty($father_name)){
          $input_error['father_name']="father_name is required";
      }
      if(empty($mother_name)){
          $input_error['mother_name']="mother_name is required";
      }
      if(empty($dob)){
          $input_error['dob']="dob is required";
      }
      if(empty($religion)){
        $input_error['religion']="religion is required";
    }
    if(empty($gender)){
      $input_error['gender']="gender is required";
  }
    if(empty($job_title)){
        $input_error['job_title']="job_title is required";
    }
    if(empty($blood_group)){
        $input_error['blood_group']="blood_group is required";
    }
    if(empty($nid_birth_certificate)){
        $input_error['nid_birth_certificate']="nid_birth_certificate is required";
    }
    if(empty($course_type)){
        $input_error['course_type']="course_type is required";
    }

    if(empty($phone_number)){
      $input_error['phone_number']="phone_number is required";
  }
  if(empty($guardian_number)){
      $input_error['guardian_number']="guardian_number is required";
  }
  if(empty($email)){
      $input_error['email']="email is required";
  }
  if(empty($divisions)){
      $input_error['divisions']="divisions is required";
  }
  if(empty($distr)){
      $input_error['distr']="distr is required";
  }

  if(empty($thana)){
    $input_error['thana']="thana is required";
}
if(empty($post_office)){
    $input_error['post_office']="post_office is required";
}
if(empty($village)){
    $input_error['village']="village is required";
}
if(empty($session)){
    $input_error['session']="session is required";
}
if(empty($course)){
    $input_error['course']="course is required";
}
if(empty($reg_type)){
  $input_error['reg_type']="reg_type is required";
}
if(empty($total_fee)){
  $input_error['total_fee']="total_fee is required";
}

     
              
$insert_query=mysqli_query($db_con,"INSERT INTO `admission`(`name`, `father_name`, `mother_name`, `dob`, `religion`, `gender`, `job_title`, `blood_group`, `nid_birth_certificate`, `course_type`, `phone_number`, `guardian_number`, `email`, `divisions`, `distr`, `thana`, `post_office`, `village`, `session`, `course`, `reg_type`, `total_fee`) VALUES ('$name','$father_name','$mother_name','$dob','$religion','$gender','$job_title','$blood_group','$nid_birth_certificate','$course_type','$phone_number','$guardian_number','$email','$divisions','$distr','$thana','$post_office','$village','$session','$course','$reg_type','$total_fee')");
              if($insert_query){
          echo '<script>
                       alert("Successfully registered");
                 window.location.href="admition.php";
                </script>
                      ';
         $name=false;
         $father_name=false;
         $mother_name=false;
         $dob=false;
         $religion=false;
         $gender=false;
         $job_title=false;
         $blood_group=false;
         $nid_birth_certificate=false;
         $course_type=false;
         $phone_number=false;
         $guardian_number=false;
         $email=false;
         $divisions=false;
         $distr=false;
         $thana=false;
         $post_office=false;
         $village=false;
         $session=false;
         $course=false;
         $reg_type=false;
         $total_fee=false;
       
                                                
     }else{
      echo '<script>
      alert("data not registered");

</script>
     ';
     }

                       
          

      






?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h3 style="color: #e91e63; padding: 15px;">ব্যাক্তিগত তথ্য(Only English)</h3>
        <div class="row">
<div class="col-md-6" style="padding: 15px;">
    <form>
        <div class="mb-3">
          <label for="" class="form-label">ছাত্র/ছাত্রীর নাম</label>
          <input type="text" class="form-control" id="name" name="name">
        </div>
        <div class="mb-3">
          <label for="" class="form-label">পিতার নাম</label>
          <input type="text" class="form-control" id="father_name" name="father_name">
        </div>
        <div class="mb-3">
            <label for="" class="form-label">মাতার নাম</label>
            <input type="text" class="form-control" id="mather_name" name="mother_name">
          </div>
          <div class="mb-3">
            <label for="" class="form-label">জন্ম তারিখ</label>
            <input type="date" class="form-control" name="dob" value="">
          </div>
       
          <div class="mb-6">
            <label class="form-label">ধর্ম</label>
            <br>
            <select name="religion" id="" class="form-select" value="">
              <option value="Islam">Islam</option>
              <option value="Hindu">Hindu</option>
              <option value="Buddh">Buddh</option>
              <option value="Christian">Christian</option>
            </select>
            <br>
          </div>
          
           
   
         
      </form>
        </div>
        
        <div class="col-md-6" style="padding: 15px;">
            <form style="padding: 15px;">
              <div class="mb-3">
                <label for="" class="form-label">লিঙ্গ</label>
                <br>
                <select name="gender" id="" class="form-select " value="">
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              
                <div class="mb-3">
                  <label for="" class="form-label">পেশা</label>
                  <br>
                  <select name="job_title" id="job_title" class="form-select " value="">
                    <option value="Student">Student</option>
                    <option value="Government employee">Government employee</option>
                    <option value="Private employee">Private employee</option>
                    <option value="Others">Others</option>			
              </select>
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">রক্তের গ্রুপ</label>
                    <br>
                    <select name="blood_group" id="blood_group" class="form-select " value="">
									
                      <option>Select Blood Group</option>
                      <option value="Null">Unknown</option>
                      <option value="A+">A+</option>
                      <option value="A-">A-</option>
                      <option value="AB+">AB+</option>
                      <option value="AB-">AB-</option>
                      <option value="B+">B+</option>
                      <option value="B-">B-</option>
                      <option value="O+">O+</option>
                      <option value="O-">O-</option>
                    </select>
                  </div>
                  <div class="mb-3">
                    <label for="" class="form-label">আইডি কার্ড/জন্ম নিবন্ধন</label>
                    <input type="text" class="form-control " name="nid_birth_certificate" value="">
                  </div>
               
                  <div class="mb-3">
                    <label for="" class="form-label">কোর্স টাইপ</label>
                    <br>
                    <select name="course_type" id="course_type" class="form-select " value="">
                      <option value="Offline">Offline</option>
                      <option value="Online">Online</option>
                        
                </select>
                  </div>
                
                 
              </form>



        </div>
        </div>
    





    
      </div>

      <div class="container">

        <h3 style="color: #e91e63; padding: 15px;">যোগাযোগের তথ্য(Only English)</h3>

<div class="row">

  <div class="col-md-6" style="padding: 15px;">
    <form>
      <div class="mb-3">
        <label for="" class="form-label">মোবাইল নাম্বার</label>
        <input type="text" class="form-control " pattern="01[1|3|4|9|7|8|6|5][0-9]{8}" name="phone_number" value="">
      </div>
      <div class="mb-3">
        <label for="" class="form-label">অভিভাবকের মোবাইল নাম্বার</label>
        <input type="text" class="form-control " name="guardian_number" pattern="01[1|3|4|9|7|8|6|5][0-9]{8}" value="">
      </div>
      <div class="mb-3">
          <label for="" class="form-label">ই-মেইল</label>
          <input type="email" class="form-control " name="email" value="">
        </div>
        <div class="mb-3">
          <label for="divisions" class="form-label">বিভাগ</label>
          <br>
          <select name="divisions" class="form-select " id="divisions" onchange="divisionsList();">
            <option disabled="" selected="">Select Division</option>
            <option value="Barishal">Barishal</option>
            <option value="Chattogram">Chattogram</option>
            <option value="Dhaka">Dhaka</option>
            <option value="Khulna">Khulna</option>
            <option value="Mymensingh">Mymensingh</option>
            <option value="Rajshahi">Rajshahi</option>
            <option value="Rangpur">Rangpur</option>
            <option value="Sylhet">Sylhet</option>
        </select>
        </div>

       
    </form>



</div>


<div class="col-md-6" style="padding: 15px;">
  <form>
    <div class="mb-3">
      <label for="" class="form-label">জেলা</label>
      <input type="name" class="form-control" id="distr" name="distr">

    </div>
    <div class="mb-3">
      <label for="" class="form-label">থানা</label>
      <input type="text" class="form-control" id="thana_print" name="thana">
      
    </div>
    <div class="mb-3">
        <label for="" class="form-label">পোস্ট অফিস</label>
        <input type="text" class="form-control " name="post_office" value="">
      </div>
      <div class="mb-3">
        <label for="" class="form-label">গ্রাম</label>
        <input type="text" class="form-control " name="village" value="">
      </div>

     
  </form>



</div>




</div>

      </div>


      <div class="container">

        <h3 style="color: #e91e63; padding: 15px;">কোর্সের তথ্য(Only English)</h3>

        <div class="row">
          <div class="col-md-6" style="padding: 15px;">
            <form>
              <div class="mb-3">
                <label for="session" class="form-label">সেশন</label>
                <br>
                <select name="session" class="form-select " id="session">
									<option disabled="" selected="">Select Session</option>
									<option value="January-June">January-June</option>
									<option value="January-March">January-March</option>
									<option value="April-June">April-June</option>
									<option value="July-December">July-December</option>
									<option value="July-September">July-September</option>
									<option value="October-December">October-December</option>
									<option value="January-December">January-December</option>
					
							</select>
              </div>
              <div class="mb-3">
                <label for="course" class="form-label">কোর্স</label>
                <br>
                <select name="course" class="form-select " id="course">
                  <option value="Computer Office Application">Computer Office Application</option>

                      <option value="Professional Graphic Design">Professional Graphic Design</option>

                      <option value="Full Stack Web Development">Full Stack Web Development</option>

                      <option value="Video Editing">Video Editing</option>

                      <option value="Digital Marketing">Digital Marketing</option>

                      <option value="Web Design">Web Design</option>

                      <option value="ICT">ICT</option>

                  


</select>
              </div>
         
              
        
               
            </form>
        
        
        
        </div>


        <div class="col-md-6" style="padding: 15px;">
          <form>
            <div class="mb-3">
              <label for="reg_type" class="form-label">রেজিট্রেশনের ধরন</label>
              <br>
              <select name="reg_type" class="form-select " id="reg_type">
							
                <option value="Government">Government</option>
                <option value="Private">Private</option>
                <option value="No Register">No Register</option>
              
            </select>
            </div>
            <div class="mb-3">
              <label for="total_fee" class="form-label">মোট ফি</label>
              <input type="text" class="form-control " name="total_fee" value="">
            </div>
       
            
      
             
          </form>
      
      
      
      </div>
        </div>
      </div>

      <div class="container" style="padding:15px; margin-bottom: 10px;">
      
      <input type="submit" value="সাবমিট" class="btn btn-success" name="register">
      </div>



    <script src="js/bootstrap.min.js"></script>

</body>
</html>