-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 11, 2023 at 07:28 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `student_form`
--

-- --------------------------------------------------------

--
-- Table structure for table `admission`
--

CREATE TABLE `admission` (
  `roll` int(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `father_name` varchar(50) NOT NULL,
  `mother_name` varchar(50) NOT NULL,
  `dob` varchar(50) NOT NULL,
  `religion` varchar(50) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `job_title` varchar(50) NOT NULL,
  `blood_group` varchar(50) NOT NULL,
  `nid_birth_certificate` varchar(50) NOT NULL,
  `course_type` varchar(50) NOT NULL,
  `phone_number` varchar(50) NOT NULL,
  `guardian_number` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `divisions` varchar(50) NOT NULL,
  `distr` varchar(50) NOT NULL,
  `thana` varchar(50) NOT NULL,
  `post_office` varchar(50) NOT NULL,
  `village` varchar(50) NOT NULL,
  `session` varchar(50) NOT NULL,
  `course` varchar(50) NOT NULL,
  `reg_type` varchar(50) NOT NULL,
  `total_fee` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admission`
--
ALTER TABLE `admission`
  ADD PRIMARY KEY (`roll`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admission`
--
ALTER TABLE `admission`
  MODIFY `roll` int(50) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
